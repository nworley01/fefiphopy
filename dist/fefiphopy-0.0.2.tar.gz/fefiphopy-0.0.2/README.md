# fefiphopy


*This package provides functions for cleaning and analyzing fiber photometry data.*

 
It focuses mainly on the following steps:
1. Smoothing the raw data
2. Correcting Baseline
3. Standardizing signals
4. Scaling isosbestic signal
5. Calculating dF/F


